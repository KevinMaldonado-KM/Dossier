#include <iostream>

#include "Correc_Prof/type.h"
using namespace std;

void mur (CMat & Mat)
{
    const char c = '#'; //block servant d'obstacle
    unsigned i(0);
    //Ligne 1 & 15
    for (i; i < 13; ++i){
        Mat[0][i] = c;
        Mat[14][i] = c;
    }
    for (i = 22; i < 35; ++i){
        Mat[0][i] = c;
        Mat[14][i] = c;
    }
    //Ligne 2 & 14
    Mat[1][0] = c;
    Mat[13][0] = c;
    Mat[1][17] = c;
    Mat[13][17] = c;
    Mat[1][34] = c;
    Mat[13][34] = c;
    //Ligne 3 & 13
    Mat[2][0] = c;
    Mat[12][0] = c;
    Mat[2][6] = c;
    Mat[12][6] = c;
    Mat[2][9] = c;
    Mat[12][9] = c;
    Mat[2][17] = c;
    Mat[12][17] = c;
    Mat[2][25] = c;
    Mat[12][25] = c;
    Mat[2][28] = c;
    Mat[12][28] = c;
    Mat[2][34] = c;
    Mat[12][34] = c;
    //Ligne 4 & 12
    Mat[3][0] = c;
    Mat[11][0] = c;
    for(i = 2; i < 7; ++i){
        Mat[3][i] = c;
        Mat[11][i] = c;
    }
    for (i = 9; i < 13; ++i){
        Mat[3][i] = c;
        Mat[11][i] = c;
    }
    Mat[3][17] = '#';
    Mat[11][17] = '#';
    for (i = 22; i < 26; ++i){
        Mat[3][i] = c;
        Mat[11][i] = c;
    }
    for (i = 28; i < 33; ++i){
        Mat[3][i] = c;
        Mat[11][i] = c;
    }
    Mat[3][34] = c;
    Mat[11][34] = c;
    //Ligne 5 & 11
    Mat[4][0] = c;
    Mat[10][0] = c;
    Mat[4][2] = c;
    Mat[10][2] = c;
    Mat[4][32] = c;
    Mat[10][32] = c;
    Mat[4][34] = c;
    Mat[10][34] = c;
    //Ligne 6 & 10
    Mat[5][0] = c;
    Mat[9][0] = c;
    for (i = 13; i < 16; ++i){
        Mat[5][i] = c;
        Mat[9][i] = c;
    }
    for (i = 19; i < 22; ++i){
        Mat[5][i] = c;
        Mat[9][i] = c;
    }
    Mat[5][34] = c;
    Mat[9][34] = c;
    //Ligne 7 & 9
    Mat[6][0] = c;
    Mat[8][0] = c;
    Mat[6][13] = c;
    Mat[8][13] = c;
    Mat[6][21] = c;
    Mat[8][21] = c;
    Mat[6][34] = c;
    Mat[8][34] = c;
    //Ligne 8
    for (i = 5; i < 10; ++i){
        Mat[7][i] = c;
    }
    for (i = 25; i < 30; ++i){
        Mat[7][i] = c;
    }
    Mat[7][0] = c;
    Mat[7][34] = c;

}

void piece (CMat & Mat)
{
    const char c = '.'; //Servant de pièce

    for (unsigned i(3); i < 12; ++i)
    {
        Mat[i][1] = c;
    }

    for (unsigned i(3); i < 12; ++i)
    {
        Mat[i][33] = c;
    }

    for (unsigned i(6); i < 15; ++i)
    {
        Mat[1][i] = c;
        Mat[13][i]= c;
    }

    for (unsigned i(20); i < 29; ++i)
    {
        Mat[1][i] = c;
        Mat[13][i]= c;
    }

    for (unsigned i(14); i < 21; ++i)
    {
        Mat[0][i] = c;
        Mat[14][i]= c;
    }

    for (unsigned i(6); i < 9; ++i)
    {
        Mat[i][2] = c;
        Mat[i][3] = c;

        Mat[i][32] = c;
        Mat[i][31] = c;

        Mat[i][3] = c;
        Mat[i][11] = c;

        Mat[i][23] = c;
    }

    for (unsigned i(4); i < 11; ++i)
    {
        Mat[5][i] = c;
        Mat[9][i] = c;
    }

    for (unsigned i(24); i < 31; ++i)
    {
        Mat[5][i] = c;
        Mat[9][i] = c;
    }

    for (unsigned i(10); i < 13; ++i)
    {
        Mat[i][7] = c;
        Mat[i][8] = c;

        Mat[i][26] = c;
        Mat[i][27] = c;
    }

    for (unsigned i(2); i < 5; ++i)
    {
        Mat[i][7] = c;
        Mat[i][8] = c;

        Mat[i][26] = c;
        Mat[i][27] = c;
    }

    for (unsigned i (12); i < 23; ++i)
    {
        Mat[4][i] = c;
        Mat[4][i] = c;

        Mat[10][i] = c;
        Mat[10][i] = c;
    }

    Mat[7][14] = c;
    Mat[7][15] = c;
    Mat[7][16] = c;

    Mat[7][18] = c;
    Mat[7][19] = c;
    Mat[7][20] = c;


    Mat[6][17] = c;

    Mat[8][17] = c;



}
