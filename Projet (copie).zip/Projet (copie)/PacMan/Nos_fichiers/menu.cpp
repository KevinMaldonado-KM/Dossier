#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "menu.h"
#include "Correc_V2/gameV2.h"
#include "Nos_fichiers/ModeIA/gameIA.h"

using namespace std;


void choix_couleur(string & couleur)
{

    unsigned choix;
    cout << "Joueur 1 : Choisissez votre couleur: ";
    cin >> choix;

    switch (choix)
    {
    case 1 :
        couleur = "KBlack";
        break;
    case 2 :
        couleur = "KRed";
        break;
    case 3 :
        couleur = "KGreen" ;
        break;
    case 4 :
        couleur = "KYellow" ;
        break;
    case 5 :
        couleur = "KBlue" ;
        break;
    case 6 :
        couleur = "KMagenta";
        break;
    case 7 :
        couleur = "KCyan";
        break;
    }
} //choix_couleur1 ()
void choix_couleur2(string & couleur)
{

    unsigned choix;
    cout << "Joueur 2 : Choisissez votre couleur: ";
    cin >> choix;

    switch (choix)
    {
    case 1 :
        couleur = "KBlack";
        break;
    case 2 :
        couleur = "KRed";
        break;
    case 3 :
        couleur = "KGreen" ;
        break;
    case 4 :
        couleur = "KYellow" ;
        break;
    case 5 :
        couleur = "KBlue" ;
        break;
    case 6 :
        couleur = "KMagenta";
        break;
    case 7 :
        couleur = "KCyan";
        break;
    }
} //choix_couleur2 ()

void choixcarac (char & carac)
{
    unsigned choix;
    cout << "Joueur 1 : Choisissez votre charactère" << endl;
    cin >> choix;
    switch (choix)
    {
    case 1 :
        carac = 'X';
        break;
    case 2 :
        carac = 'O';
        break;
    case 3 :
        carac = '@';
        break;
    case 4 :
        carac = '$';
        break;
    case 5 :
        carac = '%';
        break;
    case 6 :
        carac = '+';
        break;

    }
} //choixcarac ()

void choixcarac2 (char & carac)
{
    unsigned choix;
    cout << "Joueur 2 : Choisissez votre charactère" << endl;
    cin >> choix;
    switch (choix)
    {
    case 1 :
        carac = 'X';
        break;
    case 2 :
        carac = 'O';
        break;
    case 3 :
        carac = '@';
        break;
    case 4 :
        carac = '$';
        break;
    case 5 :
        carac = '%';
        break;
    case 6 :
        carac = '+';
        break;

    }
} //choixcarac2 ()

void InitParam (const string & monFichier)
{
    ofstream ofs(monFichier);
    if (!ofs.is_open())
    {
        cout << "erreur" << endl;
        return;
    }
    char Kup = 'z';
    char Kdown = 's';
    char Kleft = 'q';
    char Kright = 'd';

    ofs << "KeyUp : " << Kup << endl;
    ofs << "KeyDown : " << Kdown<< endl;
    ofs << "KeyLeft : " << Kleft<< endl;
    ofs << "KeyRight : " << Kright<< endl;

    ofs << "NbColumn : " << 15 << endl;
    ofs << "NbRow : " << 35 << endl;

    string couleur1;
    string couleur2;
    choix_couleur(couleur1);
    choix_couleur2(couleur2);
    ofs << "ColorP1 : " << couleur1 << endl;
    ofs << "ColorP2 :  " << couleur2 << endl;

    cout << "\033[H\033[2J";
    AfficheFich("carac.txt");
    char Token1 = 'O';
    char Token2 = 'X';
    choixcarac(Token1);
    choixcarac2(Token2);
    ofs << "TokenP1 : " << Token1<< endl;
    ofs << "TokenP2 : " << Token2<< endl;
}

void AfficheFich (const string & kfichier) // Affiche les Fichiers
{
    // if (! ofs.is_open()){
    // cout << "Erreur" << endl;
    // return;
    ifstream texte (kfichier.c_str());
    if(texte.is_open() == true)
    {
        string ligne;
        while (getline(texte, ligne))
        {
            cout << ligne << endl;
        }
    }

    else
    {
        cout << "ERRUR AFFICHAGE" << endl;
    }
} //AfficheFich ()


int menu () { // int menu dans le projet (servira à choisir menu)
    AfficheFich("accueil.txt");
    cout << "choisir :  ";
    unsigned reponse=0;
    cin >> reponse;
    while (true)
    {
        if (reponse == 1)
        {
            reponse = 0;
            while (reponse != 1 | reponse != 2){
                cout << "\033[H\033[2J";
                AfficheFich("Interface_mode_jeu.txt");
                cin >> reponse;
                if (reponse == 1){
                    try
                    {
                        return ppal ();
                    }
                    catch (...)
                    {
                        cerr << "ca c'est mal passe quelque part" << endl;
                        return 1;
                    }
                }
                if (reponse == 2){
                    try
                    {
                        return ppalIa ();
                    }
                    catch (...)
                    {
                        cerr << "ca c'est mal passe quelque part" << endl;
                        return 1;
                    }
                }

            }
        }
        if (reponse == 2)
        {
            cout << "\033[H\033[2J";
            AfficheFich("couleur.txt"); // faudra faire un return sur un int parametre
            InitParam("../PacMan/Nos_fichiers/config.yaml");
            try
            {
                return ppal ();
            }
            catch (...)
            {
                cerr << "ca c'est mal passe quelque part" << endl;
                return 1;
            }
        }
        if (reponse == 3)
        {
           reponse = 0;
           cout << "\033[H\033[2J";
           cout << "Classement de la partie précédente" << endl;
           AfficheFich("classement.txt");
           cout << "[1] Retour Au Menu |" << "|[2] Quitter Le Jeu" << endl;
           cin >> reponse;
           if (reponse == 1){
               cout << "\033[H\033[2J";
               try
               {
                   return menu ();
               }
               catch (...)
               {
                   cerr << "ca c'est mal passe quelque part" << endl;
                   return 1;
               }
           }
           else{
               exit(0);
           }
        }
        if (reponse == 4){
            reponse = 0;
            cout << "\033[H\033[2J";
            AfficheFich("regles.txt");
            cin >> reponse;
            if (reponse == 1){
                try
                {
                    return ppal ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            if (reponse == 2){
                try
                {
                    return ppalIa ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            if (reponse == 3){
                cout << "\033[H\033[2J";
                try
                {
                    return menu ();
                }
                catch (...)
                {
                    cerr << "ca c'est mal passe quelque part" << endl;
                    return 1;
                }
            }
            else{
                exit(0);
            }
        }
        else {
            exit(0);
        }
        return 0;
    }
} //menu ()
