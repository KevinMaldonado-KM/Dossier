#ifndef TYPEIA_H
#define TYPEIA_H

#include <string>
#include <vector>
#include <map>

struct AuthorizedKeyIA {
    /** List of authorized key for the type char in a struct CMyParam*/
    const std::vector <std::string> VParamCharIA {"KeyUp", "KeyDown", "KeyLeft", "KeyRight", "TokenP1", "IaP1", "IaP2", "IaP3", "IaP4"};
    /** List of authorized key for the type string in a struct CMyParam*/
    const std::vector <std::string> VParamStringIA {"ColorTokenP1", "ColorIaP1", "ColorIaP2", "ColorIaP3", "ColorIaP4"};
    /** List of authorized key for the type unsigned in a struct CMyParam*/
    const std::vector <std::string> VParamUnsignedIA {"NbRow", "NbColumn"};
};

/**
 * @brief KAuthorizedKey
 */
const AuthorizedKeyIA KAuthorizedKeyIA;


#endif // TYPEIA_H
