#include <iostream>
#include "Classement.h"
#include <string>
#include <fstream>

using namespace std;

void ChangClassement(unsigned & PartyNum, string & pseudo, unsigned & point, const string & nomfichier){
    ofstream ofs (nomfichier);
    if (ofs.is_open() != true)
    {
        cout << "Erreur" << endl;
        return;
    }

    ofs << "Meilleur Joueur \n" << endl;
    ofs << "Pseudo : " << pseudo << endl;
    ofs << "Nombre de tours : " << PartyNum << endl;
    ofs << "Points : " << point << endl;


}
