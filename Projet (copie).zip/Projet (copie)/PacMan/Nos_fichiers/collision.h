#ifndef COLLISION_H
#define COLLISION_H
#include "Correc_Prof/type.h"

void mur (CMat & Mat);

void piece (CMat & Mat);

#endif // COLLISION_H
