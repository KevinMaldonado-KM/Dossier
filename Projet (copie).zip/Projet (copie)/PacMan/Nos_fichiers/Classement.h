#ifndef CLASSEMENT_H
#define CLASSEMENT_H

#include <string>

void ChangClassement(unsigned & PartyNum, std::string & pseudo, unsigned & point, const std::string & nomfichier);

#endif // CLASSEMENT_H
