#ifndef PARAMSIA_H
#define PARAMSIA_H

#include "Correc_Prof/type.h"
#include "Nos_fichiers/typeIA.h"

int LoadParamsIA (CMyParam & Param, const std::string & FileName);

#endif // PARAMSIA_H
