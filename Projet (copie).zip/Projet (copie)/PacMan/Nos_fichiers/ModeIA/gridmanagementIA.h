#ifndef GRIDMANAGEMENTIA_H
#define GRIDMANAGEMENTIA_H

#include "Correc_Prof/type.h"

void DisplayGridIa (const CMat & Mat, const CMyParam & Param);

void InitGridIa (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer1, CPosition & PosIa1, CPosition & PosIa2, CPosition & PosIa3, CPosition & PosIa4);

#endif // GRIDMANAGEMENTIA_H
