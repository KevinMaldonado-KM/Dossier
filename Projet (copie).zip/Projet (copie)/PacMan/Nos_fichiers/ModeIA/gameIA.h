#ifndef GAMEIA_H
#define GAMEIA_H

#include "Correc_Prof/type.h"

void MouveEnnemies (CMat & Mat, unsigned & MovRand, CPosition & Pos);

int ppalIa (void);

#endif // GAMEIA_H
