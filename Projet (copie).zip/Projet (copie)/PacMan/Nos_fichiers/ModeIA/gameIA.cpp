#include <iostream>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <termios.h>
#include "gameIA.h"
#include "Nos_fichiers/menu.h"
#include "Nos_fichiers/collision.h"
#include "Nos_fichiers/Correc_V2/gameV2.h"
#include "gridmanagementIA.h"
#include "paramsIA.h"
#include "Nos_fichiers/Correc_V2/gridmanagementV2.h"

#include <map>


using namespace std;


void MouveEnnemies (CMat & Mat, unsigned & MovRand, CPosition & Pos)
{
    char car = Mat [Pos.first][Pos.second];
    Mat [Pos.first][Pos.second] = KEmpty;
    switch (MovRand)
    {
    case 1:

        if (Pos.first == 0) {
            break;
        }
        else {
            -- Pos.first;
        }

        if (Pos.second == 0) {
            break;
        }
        else {
            -- Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '#' | Mat[Pos.first][Pos.second] == 'X' | Mat[Pos.first][Pos.second] == '%' | Mat[Pos.first][Pos.second] == '@'| Mat[Pos.first][Pos.second] == '$')
        {
            ++Pos.second;
            ++Pos.first;
            break;
        }

        if (Mat[Pos.first][Pos.second] == 'o')
        {
            ++Pos.second;
            ++Pos.first;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }
        break;
    case 2 :

        if (Pos.first == 0) {
            Pos.first = Mat.size()-1;
            break;
        }

        if(Mat[Pos.first-1][Pos.second] == '#' | Mat[Pos.first-1][Pos.second] == 'X'| Mat[Pos.first-1][Pos.second] == '%' | Mat[Pos.first-1][Pos.second] == '@'| Mat[Pos.first-1][Pos.second] == '$')
        {
            break;
        }



        if(Mat[Pos.first-1][Pos.second] == 'o')
        {
            break;
        }

        else {
            --Pos.first;
        }


        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
            break;
        }

        break;

    case 3 :
        if (Pos.first == 0) {
            break;
        }
        else {
            -- Pos.first;
        }

        if (Pos.second == Mat[Pos.first].size()-1) {
            break;
        }
        else {
            ++ Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '#' | Mat[Pos.first][Pos.second] == 'X'| Mat[Pos.first][Pos.second] == '%' | Mat[Pos.first][Pos.second] == '@'| Mat[Pos.first][Pos.second] == '$')
        {
            --Pos.second;
            ++Pos.first;
            break;
        }
        if(Mat[Pos.first][Pos.second] == 'o')
        {
            --Pos.second;
            ++Pos.first;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    case 4 :

        if (Pos.second == 0) {
            Pos.second = Mat[Pos.first].size()-1;
            break;
        }

        if(Mat[Pos.first][Pos.second-1] == '#' | Mat[Pos.first][Pos.second-1] == 'X'| Mat[Pos.first][Pos.second-1] == '%' | Mat[Pos.first][Pos.second-1] == '@'| Mat[Pos.first][Pos.second-1] == '$')
        {

            break;
        }
        if(Mat[Pos.first][Pos.second-1] == 'o')
        {

            break;
        }

        else {
            --Pos.second;
        }



        if (Mat[Pos.first][Pos.second] == Mat[12][29]) {
            Pos.first = 2;
            Pos.second = 4;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    case 5 :

        if (Pos.second == Mat[Pos.first].size()-1) {
            Pos.second = 0;
            break;
        }

        if(Mat[Pos.first][Pos.second+1] == '#' | Mat[Pos.first][Pos.second+1] == 'X'| Mat[Pos.first][Pos.second+1] == '%' | Mat[Pos.first][Pos.second+1] == '@'| Mat[Pos.first][Pos.second+1] == '$')
        {

            break;
        }

        if(Mat[Pos.first][Pos.second+1] == 'o')
        {

            break;
        }

        else {
            ++Pos.second;
        }

        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }



        break;
    case 6 :

        if (Pos.first == Mat.size()-1) {
            break;

        }
        else {
            ++ Pos.first;
        }

        if (Pos.second == 0) {
           break;

        }

        else {
            -- Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '#' | Mat[Pos.first][Pos.second] == 'X'| Mat[Pos.first][Pos.second] == '%' | Mat[Pos.first][Pos.second] == '@'| Mat[Pos.first][Pos.second] == '$')
        {
            ++Pos.second;
            --Pos.first;
            break;
        }
        if(Mat[Pos.first][Pos.second] == 'o')
        {
            ++Pos.second;
            --Pos.first;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }
        break;
    case 7 :

        if (Pos.first == Mat.size()-1) {
            Pos.first = 0;
            break;
        }

        if(Mat[Pos.first+1][Pos.second] == '#' | Mat[Pos.first+1][Pos.second] == 'X'| Mat[Pos.first+1][Pos.second] == '%' | Mat[Pos.first+1][Pos.second] == '@'| Mat[Pos.first+1][Pos.second] == '$')
        {

            break;
        }
        if(Mat[Pos.first+1][Pos.second] == 'o' )
        {

            break;
        }
        else {
            ++Pos.first;
        }

        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    case 8 :

        if (Pos.first == Mat.size()-1) {
            break;
        } else {
            ++ Pos.first;
        }

        if (Pos.second == Mat[Pos.first].size()-1) {
            break;
        } else {
            ++ Pos.second;
        }

        if(Mat[Pos.first][Pos.second] == '#' | Mat[Pos.first][Pos.second] == 'X'| Mat[Pos.first][Pos.second] == '%' | Mat[Pos.first][Pos.second] == '@'| Mat[Pos.first][Pos.second] == '$')
        {
            --Pos.second;
            --Pos.first;
            break;
        }

        if(Mat[Pos.first][Pos.second] == 'o')
        {
            --Pos.second;
            --Pos.first;
            break;
        }


        if (Mat[Pos.first][Pos.second] == Mat[2][5]) {
            Pos.first = 12;
            Pos.second = 30;
            break;
        }

        if (Mat[Pos.first][Pos.second] == Mat[10][3]) {
            Pos.first = 8;
            Pos.second = 17;
        }

        if (Mat[Pos.first][Pos.second] == Mat[4][31]) {
            Pos.first = 6;
            Pos.second = 17;
        }

        break;
    }
    Mat [Pos.first][Pos.second] = car;
} //MouveEnnemies ()

int ppalIa (void)
{
    unsigned PartyNum (1);
    const unsigned KMaxPartyNum (250);
    CMat Mat;
    bool Victory (false);
    bool VictoryPoint (false);

    CPosition PosPlayer1, PosIa1, PosIa2, PosIa3, PosIa4;

    CMyParam Param;
    const string config = "../PacMan/Nos_fichiers/configIA.yaml";

    int RetVal = LoadParamsIA(Param, config);
    if (RetVal != 0)
    {
        return RetVal;
    }


    InitGridIa(Mat, Param, PosPlayer1, PosIa1, PosIa2, PosIa3, PosIa4);

    DisplayGridIa (Mat, Param);
    set_input_mode();
    unsigned point1 (0);
    while (PartyNum <= KMaxPartyNum && ! Victory)
    {
        cout << "tour numero : " << PartyNum << ", " << point1 << "point" << ", Joueur 1"
             << ", entrez un déplacement : "
             << endl;

        unsigned MovRand;
        srand(time(NULL));

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa1);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa2);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa3);

        MovRand = rand() % 8 + 1;
        MouveEnnemies(Mat, MovRand, PosIa4);

        char Move= 'Y';

        read(STDIN_FILENO, &Move, 1);

        Move = toupper (Move);
        MoveToken (Mat, Move, PosPlayer1, point1);

        ClearScreen();
        DisplayGridIa (Mat, Param);

        //Victiry test
        if (PosPlayer1 == PosIa1 || PosIa1 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa2 || PosIa2 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa3 || PosIa3 == PosPlayer1) Victory = true;
        if (PosPlayer1 == PosIa4 || PosIa4 == PosPlayer1) Victory = true;
        if (point1 == 90){
            VictoryPoint = true;
            break;
        }

        //Increase party's number
        if(Move != 'Y')
            ++PartyNum;
    }//while (no victory)

    if (!Victory | VictoryPoint)
    {
        reset_input_mode();
        Color (KColor.find("KGreen")->second);
        cout << "Bravo vous avez gagné"<< endl;
        return 1;
    }
    reset_input_mode();
    Color (KColor.find("KMagenta")->second);
    cout << "Vous vous êtes fais manger par un fantôme"
         << " vous avez perdu :(" << endl;
    Color (KColor.find("KReset")->second);
    return 0;
} //ppalIa ()

