#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include "paramsIA.h"


using namespace std;

int LoadParamsIA (CMyParam & Param, const std::string & FileName)
{
    ifstream ifs (FileName);
    if (!ifs.is_open())
    {
        cerr << "pas le bon fichier de configuration";
        return 2;
    }
    string Key;
    while (ifs >> Key)
    {
        char tmp;
        ifs >> tmp;
        if (find (KAuthorizedKeyIA.VParamCharIA.begin(), KAuthorizedKeyIA.VParamCharIA.end(), Key) != KAuthorizedKeyIA.VParamCharIA.end())
            ifs >> Param.MapParamChar[Key];
        else if (find (KAuthorizedKeyIA.VParamUnsignedIA.begin(), KAuthorizedKeyIA.VParamUnsignedIA.end(), Key) != KAuthorizedKeyIA.VParamUnsignedIA.end())
            ifs >> Param.MapParamUnsigned[Key];
        else if (find (KAuthorizedKeyIA.VParamStringIA.begin(), KAuthorizedKeyIA.VParamStringIA.end(), Key) != KAuthorizedKeyIA.VParamStringIA.end())
        {
            string Val;
            ifs >> Val;
            Param.MapParamString[Key] = KColor.find(Val)->second;
        }
    }
    return 0;
}
