/*!
 * \file   main.cpp
 * \authors Alain Casali, Marc Laporte
 * \date december 8 2016
 * \brief   Terminal's color management
 *          beginning of the project titled "catch me if you can"
 */

#include <iostream>
#include "Nos_fichiers/Correc_V2/gameV2.h"
#include "Nos_fichiers/menu.h"

using namespace std;
/**
 * @brief main
 *
 */
int main()
{
    menu();
} //main ()



