#ifndef GAMEIA_H
#define GAMEIA_H

/*!
 * @file gameIA.h
 * @brief Met en place des paramètres utiles pour le jeu
 * @author Alain Casali
 * @author Marc Laporte
 * @version 1.0
 * @date 18 décembre 2018
 */

#include "Correc_Prof/type.h"


/*!
 * @brief Déplacement de l'IA actuel en fonction du nombre dans le 2ème paramètre
 * @author Maldonado Kevin
 * @param[in, out] Mat : la matrice avant et après le déplacement
 * @param[in] MovRand : nombre compris entre 1 et 8, chaque nombre exprime un déplacment distinct
 * @param[in, out] Pos : la position du joueur avant et après le coup
 * @fn void MouveEnnemies (CMat & Mat, unsigned & MovRand, CPosition & Pos);
 * @version 1.0
 * @date 20 janvier 2020
 */

void MouveEnnemies (CMat & Mat, unsigned & MovRand, CPosition & Pos);

/**
 * @brief lance le jeu 1 VS IA (Niveau 1)
 * @version 1.0
 * @authors Alain Casali, Marc Laporte
 * @version 2.0
 * @author Maldonado Kevin
 * @author Ghouili Wissem
 * @return 0 si tout est bon
 * @fn int ppalIa (void);
 * @date 20 janvier 2020
 */

int ppalIa (void);

#endif // GAMEIA_H
