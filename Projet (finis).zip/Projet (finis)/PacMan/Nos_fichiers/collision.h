#ifndef COLLISION_H
#define COLLISION_H

/*!
 * @file collision.h
 * @brief Met en place des paramètres utiles pour les collisions
 * @author Alain Casali
 * @author Marc Laporte
 * @version 1.0
 * @date 18 décembre 2018
 */

#include "Correc_Prof/type.h"

/**
 * @brief Génére les "murs" en fonction de la matrice passée en paramètre
 * @author Maldonado Kevin
 * @param[out] Mat : la matrice en question
 * @fn void mur (CMat & Mat);
 * @version 1.0
 * @date 19 janvier 2021
 */

void mur (CMat & Mat);


/**
 * @brief Génére des "pieces" en fonction de la matrice passée en paramètre
 * @author Ghouili Wissem
 * @param[out] Mat : la matrice en question
 * @fn void piece (CMat & Mat);
 * @version 1.0
 * @date 21 janvier 2021
 */

void piece (CMat & Mat);

#endif // COLLISION_H
