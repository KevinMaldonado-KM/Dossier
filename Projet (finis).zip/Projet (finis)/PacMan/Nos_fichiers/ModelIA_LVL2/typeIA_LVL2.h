#ifndef TYPEIA_LVL2_H
#define TYPEIA_LVL2_H

/*!
 * \file typeIA_LVL2.h
 * \brief Définition des types d'alias utiles pour le projet
 * \author Maldonado Kevin
 * \version 3.0
 * \date 20 janvier 2021
 */

#include <string>
#include <vector>
#include <map>

/**
 * @brief Structure contenant toutes les clés autorisées dans la structure CMyParam
 */

struct AuthorizedKeyIA_LVL2 {
    /** Liste des clés autorisées pour le type char dans une structure CMyParam*/
    const std::vector <std::string> VParamCharIA_LVL2 {"KeyUp", "KeyDown", "KeyLeft", "KeyRight", "TokenP1", "IaP1", "IaP2", "IaP3", "IaP4", "IaP5", "IaP6", "IaP7"};
    /** Liste des clés autorisées pour le type string dans une structure CMyParam*/
    const std::vector <std::string> VParamStringIA_LVL2 {"ColorTokenP1", "ColorIaP1", "ColorIaP2", "ColorIaP3", "ColorIaP4", "ColorIaP5", "ColorIaP6", "ColorIaP7"};
    /** Liste des clés autorisées pour le type unsigned dans une structure CMyParam*/
    const std::vector <std::string> VParamUnsignedIA_LVL2 {"NbRow", "NbColumn"};
};

/**
 * @brief KAuthorizedKey
 */
const AuthorizedKeyIA_LVL2 KAuthorizedKeyIA_LVL2;



#endif // TYPEIA_LVL2_H
