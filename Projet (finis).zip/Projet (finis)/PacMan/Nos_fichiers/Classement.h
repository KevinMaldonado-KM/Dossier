#ifndef CLASSEMENT_H
#define CLASSEMENT_H

/**
 * @file Classement.h
 * @brief Change le fichier classement en fonction du premier, deuxième et troisième parametres
 * @author Ghouili Wissem
 * @param[out] PartyNum : le nombre
 * @param[out] pseudo : le pseudo du joueur gagnant
 * @param[out] point : le nombre de point qu'a le joueur lorsqu'il gagne
 * @param[in] nomFichier : le fichier du classement qui va être modifié
 * @fn void ChangClassement(unsigned & PartyNum, std::string & pseudo, unsigned & point, const std::string & nomfichier);
 * @version 1.0
 * @date 19 janvier 2021
 */

#include <string>

void ChangClassement(unsigned & PartyNum, std::string & pseudo, unsigned & point, const std::string & nomfichier);

#endif // CLASSEMENT_H

