#ifndef GAMEV2_H
#define GAMEV2_H

/*!
 * @file gameV2.h
 * @brief Met en place des paramètres utiles pour le jeu
 * @author Alain Casali
 * @author Marc Laporte
 * @version 1.0
 * @date 18 décembre 2018
 */

#include "Correc_Prof/type.h"


/*!
 * @brief Déplace le joueur actuel en fonction du caractère dans le 2ème paramètre
 * @author Bennai Yanis
 * @author Ghouili Wissem
 * @author Maldonado Kevin
 * @author Alali Djessim
 * @param[in, out] Mat : la matrice avant et après le déplacement
 * @param[in] Move : la touche appuyée l'utilisateur
 * @param[in, out] Pos : la position du joueur avant et après le coup
 * @param[out] Point : augmente le nombre de point lorsque le joueur va sur une piece
 * @fn void MoveToken (CMat & Mat, const char & Move, CPosition & Pos, unsigned & point);
 * @version 2.0
 * @date 20 janvier 2020
 */

void MoveToken (CMat & Mat, const char & Move, CPosition & Pos, unsigned & point);


/*!
 * @brief Réinitialisation du mode non canonique
 * @fn void reset_input_mode (void);
 * @version 1.0
 * @date 12 janvier 2020
 */

void reset_input_mode (void);


/*!
 * @brief Mode non canonique
 * @fn void set_input_mode (void);
 * @version 1.0
 * @date 12 janvier 2020
 */
void set_input_mode (void);


/*!
 * @brief Jeu du pile ou face afin de déterminer quel joueur va jouer en premier
 * @author Maldonado Kevin
 * @param[out] Valeur : ce que le joueur a choisis (donc pile ou face)
 * @return le résultat du pile ou face
 * @fn bool PileouFace (unsigned valeur);
 * @version 1.0
 * @date 12 janvier 2020
 */

bool PileouFace (unsigned valeur);


/**
 * @brief le main du jeu
 * @author Maldonado Kevin
 * @author Ghouili Wissem
 * @return 0 si tout est bon
 * @fn int ppal ();
 */

int ppal ();

#endif // GAMEV2_H
